<?php

Mock::generatePartial(
        'HTMLPurifier_Definition',
        'HTMLPurifier_DefinitionTestable',
        array('doSetup'));

// vim: et sw=4 sts=4
